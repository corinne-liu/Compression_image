#ifndef QTC_H
    #define QTC_H

    // Inclusion des bibliothèques nécessaires pour faire la bibliothèque dynamique
    #include "bitstream.h"
    #include "compression.h"
    #include "filtrage.h"
    #include "decompression.h"
    #include "quadtree.h"

#endif